# moonraker-esteps

A Moonraker plugin that provides an **interactive web panel** for guided E-Step (rotation distance) calibration in Klipper — no more running macros manually or doing math yourself.

## Features

- 🧙 **Step-by-step wizard** — walks you through the whole process
- 🌡️ **Auto heats hotend** to your specified temperature  
- 📏 **Tells you exactly where to mark** your filament
- ⚙️ **Extrudes 100mm** slowly and precisely
- 🧮 **Calculates and applies** the new `rotation_distance` live
- 💾 **Saves to printer.cfg** with one button press

## Installation

SSH into your Raspberry Pi and run:

```bash
cd ~/
git clone https://github.com/YOUR_USER/moonraker-esteps.git
cd moonraker-esteps
make install
```

## Configuration

### moonraker.conf
```ini
[esteps_calibrator]
# All settings are optional
# preheat_temp: 200      # default hotend temp for calibration
# extrude_speed: 1       # extrusion speed in mm/s (keep slow for accuracy)

# Optional: enable auto-updates via Mainsail/Fluidd
[update_manager esteps_calibrator]
type: git_repo
primary_branch: main
path: ~/moonraker-esteps
origin: https://github.com/YOUR_USER/moonraker-esteps.git
managed_services: klipper moonraker
```

### printer.cfg
```ini
[include esteps_calibrator.cfg]
```

## Using the Panel

After installing, open the web panel in your browser:

```
http://YOUR_PRINTER_IP/server/files/config/esteps_panel.html
```

Or in Mainsail/Fluidd, browse to **Config Files** → `esteps_panel.html` → open in a new tab.

The panel will guide you through 5 steps:

1. **Heat Up** — set temperature and start
2. **Mark** — mark filament 120mm from extruder while it heats
3. **Extrude** — printer extrudes 100mm automatically  
4. **Measure** — measure how much filament is left from your mark
5. **Save** — new `rotation_distance` is applied live and saved

## How the Math Works

We mark 120mm and extrude 100mm. If the extruder is perfectly calibrated, your mark should end up exactly 20mm from the extruder entrance. 

- **Actual extruded** = 120mm (mark distance) − remainder you measured
- **New rotation_distance** = current_rotation_distance × (actual / 100)

## Structure

```
moonraker-esteps/
├── component/
│   └── esteps_calibrator.py   # Moonraker component + REST API
├── klipper_macro/
│   └── esteps_calibrator.cfg  # Klipper macros
├── panel/
│   └── esteps_panel.html      # Self-contained web UI wizard
├── install.sh                 # Installer script
├── Makefile                   # make install / make uninstall
└── README.md
```

## API Endpoints

The component exposes these Moonraker endpoints:

| Method | Path | Description |
|--------|------|-------------|
| GET | `/server/esteps/status` | Current state + results |
| POST | `/server/esteps/start` | Start calibration (param: `temp`) |
| POST | `/server/esteps/mark_done` | Proceed to extrusion |
| POST | `/server/esteps/calculate` | Calculate (param: `remainder`) |
| POST | `/server/esteps/save` | Save via SAVE_CONFIG |
| POST | `/server/esteps/reset` | Reset to idle |

## License

GPL-3.0
