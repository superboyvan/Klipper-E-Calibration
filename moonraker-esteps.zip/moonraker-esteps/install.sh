#!/bin/bash
# Installer for moonraker-esteps
# Mirrors the structure of moonraker-timelapse by mainsail-crew

SRCDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Default paths (same as standard Klipper/Moonraker installations)
MOONRAKER_HOME="${HOME}/moonraker"
KLIPPER_CONFIG_DIR="${HOME}/printer_data/config"

# Fallback for older installations
if [ ! -d "${KLIPPER_CONFIG_DIR}" ]; then
    KLIPPER_CONFIG_DIR="${HOME}/klipper_config"
fi

MOONRAKER_TARGET_DIR="${MOONRAKER_HOME}/moonraker/components"
SYSTEMDDIR="/etc/systemd/system"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${GREEN}======================================${NC}"
    echo -e "${GREEN}   moonraker-esteps Installer${NC}"
    echo -e "${GREEN}======================================${NC}"
    echo ""
}

check_dependencies() {
    echo "Checking dependencies..."

    if [ ! -d "${MOONRAKER_HOME}" ]; then
        echo -e "${RED}ERROR: Moonraker not found at ${MOONRAKER_HOME}${NC}"
        echo "Please install Moonraker first."
        exit 1
    fi

    if [ ! -d "${MOONRAKER_TARGET_DIR}" ]; then
        echo -e "${RED}ERROR: Moonraker components directory not found at ${MOONRAKER_TARGET_DIR}${NC}"
        exit 1
    fi

    echo -e "${GREEN}✓ Moonraker found${NC}"
}

install_component() {
    echo "Installing Moonraker component..."

    if [ -d "${MOONRAKER_TARGET_DIR}" ]; then
        ln -sf "${SRCDIR}/component/esteps_calibrator.py" \
               "${MOONRAKER_TARGET_DIR}/esteps_calibrator.py"
        echo -e "${GREEN}✓ Moonraker component linked${NC}"
    else
        echo -e "${RED}ERROR: ${MOONRAKER_TARGET_DIR} not found.${NC}"
        exit 1
    fi
}

install_klipper_cfg() {
    echo "Installing Klipper macro file..."

    if [ -d "${KLIPPER_CONFIG_DIR}" ]; then
        ln -sf "${SRCDIR}/klipper_macro/esteps_calibrator.cfg" \
               "${KLIPPER_CONFIG_DIR}/esteps_calibrator.cfg"
        echo -e "${GREEN}✓ Klipper macro file linked to ${KLIPPER_CONFIG_DIR}${NC}"
    else
        echo -e "${YELLOW}WARNING: Could not find Klipper config dir at ${KLIPPER_CONFIG_DIR}${NC}"
        echo "Copy klipper_macro/esteps_calibrator.cfg to your config folder manually."
    fi
}

install_panel() {
    echo "Installing web panel..."

    PANEL_DIR="${KLIPPER_CONFIG_DIR}/.moonraker_esteps_panel"
    if [ -d "${KLIPPER_CONFIG_DIR}" ]; then
        cp "${SRCDIR}/panel/esteps_panel.html" "${KLIPPER_CONFIG_DIR}/esteps_panel.html"
        echo -e "${GREEN}✓ Panel HTML copied to ${KLIPPER_CONFIG_DIR}/esteps_panel.html${NC}"
    fi
}

restart_services() {
    echo "Restarting services..."

    if [ "$(sudo systemctl list-units --full --all -t service --no-legend | grep -F "moonraker.service")" ]; then
        sudo systemctl restart moonraker
        echo -e "${GREEN}✓ Moonraker restarted${NC}"
    fi
}

print_next_steps() {
    echo ""
    echo -e "${GREEN}======================================${NC}"
    echo -e "${GREEN}   Installation Complete!${NC}"
    echo -e "${GREEN}======================================${NC}"
    echo ""
    echo "Next steps:"
    echo ""
    echo "1. Add to moonraker.conf:"
    echo ""
    echo "   [esteps_calibrator]"
    echo "   # preheat_temp: 200    # optional"
    echo "   # extrude_speed: 1     # mm/s, optional"
    echo ""
    echo "   [update_manager esteps_calibrator]"
    echo "   type: git_repo"
    echo "   primary_branch: main"
    echo "   path: ~/moonraker-esteps"
    echo "   origin: https://github.com/YOUR_USER/moonraker-esteps.git"
    echo "   managed_services: klipper moonraker"
    echo ""
    echo "2. Add to printer.cfg:"
    echo ""
    echo "   [include esteps_calibrator.cfg]"
    echo ""
    echo "3. Restart Moonraker and Klipper"
    echo ""
    echo "4. Open the E-Steps Calibrator panel:"
    echo "   http://YOUR_PRINTER_IP/server/files/config/esteps_panel.html"
    echo ""
}

# ---- Main ----
print_header
check_dependencies
install_component
install_klipper_cfg
install_panel
restart_services
print_next_steps
