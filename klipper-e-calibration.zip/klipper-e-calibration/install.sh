#!/bin/bash
# ============================================================
#  Klipper E-Steps Calibrator - Installer
#  Installs:
#    1. Moonraker component
#    2. Klipper macro cfg
#    3. Standalone HTML panel (accessible via browser)
#    4. Mainsail Vue panel (if Mainsail source is present)
# ============================================================

set -e

REPO_URL="https://github.com/superboyvan/Klipper-E-Calibration"
# Always use the directory the script actually lives in as the source
INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MOONRAKER_COMPONENTS="${HOME}/moonraker/moonraker/components"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

ok()   { echo -e "${GREEN}  ✓ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
err()  { echo -e "${RED}  ✗ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }

# ── Detect config dir ────────────────────────────────────────
detect_config_dir() {
    if   [ -d "${HOME}/printer_data/config" ]; then
        echo "${HOME}/printer_data/config"
    elif [ -d "${HOME}/klipper_config" ]; then
        echo "${HOME}/klipper_config"
    else
        echo ""
    fi
}

CONFIG_DIR=$(detect_config_dir)

# ── Detect Mainsail source dir ───────────────────────────────
detect_mainsail_src() {
    for candidate in \
        "${HOME}/mainsail-src" \
        "${HOME}/mainsail" \
        "/opt/mainsail" \
        "${HOME}/klipper-webui"; do
        if [ -f "${candidate}/src/main.ts" ] || [ -f "${candidate}/src/main.js" ]; then
            echo "${candidate}"
            return
        fi
    done
    echo ""
}

MAINSAIL_SRC=$(detect_mainsail_src)

# ────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Klipper E-Steps Calibrator Installer   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Moonraker component ──────────────────────────────
echo ""
info "Installing Moonraker component..."
if [ -d "${MOONRAKER_COMPONENTS}" ]; then
    ln -sf "${INSTALL_DIR}/moonraker-component/esteps_calibrator.py" \
           "${MOONRAKER_COMPONENTS}/esteps_calibrator.py"
    ok "Moonraker component linked"
else
    err "Moonraker components dir not found at ${MOONRAKER_COMPONENTS}"
    err "Install Moonraker first, or check the path."
    exit 1
fi

# ── Step 2: Klipper macro cfg ────────────────────────────────
echo ""
info "Installing Klipper macro file..."
if [ -n "${CONFIG_DIR}" ]; then
    ln -sf "${INSTALL_DIR}/klipper-macro/esteps_calibrator.cfg" \
           "${CONFIG_DIR}/esteps_calibrator.cfg"
    ok "Macro file linked to ${CONFIG_DIR}/esteps_calibrator.cfg"
else
    warn "Could not find Klipper config dir. Copy manually:"
    warn "  ${INSTALL_DIR}/klipper-macro/esteps_calibrator.cfg"
fi

# ── Step 3: Standalone HTML panel ───────────────────────────
echo ""
info "Installing standalone HTML panel..."
if [ -n "${CONFIG_DIR}" ]; then
    cp "${INSTALL_DIR}/panel/esteps_panel.html" \
       "${CONFIG_DIR}/esteps_panel.html"
    ok "HTML panel copied to ${CONFIG_DIR}/esteps_panel.html"
    ok "Access it at: http://YOUR_PRINTER_IP/server/files/config/esteps_panel.html"
else
    warn "Skipped HTML panel (no config dir found)"
fi

# ── Step 4: Mainsail Vue panel (optional) ────────────────────
echo ""
info "Checking for Mainsail source..."
if [ -n "${MAINSAIL_SRC}" ]; then
    ok "Mainsail source found at ${MAINSAIL_SRC}"
    info "Installing Vue panel component..."

    PANELS_DIR="${MAINSAIL_SRC}/src/components/panels"
    STORE_DIR="${MAINSAIL_SRC}/src/store/esteps"

    mkdir -p "${STORE_DIR}"
    cp "${INSTALL_DIR}/mainsail-panel/EStepsCalibratorPanel.vue" "${PANELS_DIR}/"
    cp "${INSTALL_DIR}/mainsail-panel/esteps-store.ts"           "${STORE_DIR}/index.ts"
    ok "Vue component and store installed"

    # Patch en.json locale
    LOCALE_FILE="${MAINSAIL_SRC}/src/locales/en.json"
    if [ -f "${LOCALE_FILE}" ] && command -v python3 &>/dev/null; then
        python3 - <<PYEOF
import json, sys

with open('${LOCALE_FILE}', 'r') as f:
    existing = json.load(f)

with open('${INSTALL_DIR}/mainsail-panel/en.json', 'r') as f:
    new_strings = json.load(f)

# Deep merge under "Panels" key
existing.setdefault('Panels', {}).update(new_strings.get('Panels', {}))

with open('${LOCALE_FILE}', 'w') as f:
    json.dump(existing, f, indent=4, ensure_ascii=False)

print("  Locale strings merged")
PYEOF
        ok "Locale strings merged into en.json"
    else
        warn "Could not auto-merge locale. Manually merge mainsail-panel/en.json into ${LOCALE_FILE}"
    fi

    echo ""
    warn "MANUAL STEPS REQUIRED to wire the Vue panel into Mainsail:"
    echo "  See ${INSTALL_DIR}/WIRING.md for exact instructions."
    echo "  Then rebuild Mainsail: cd ${MAINSAIL_SRC} && npm run build"
else
    warn "Mainsail source not found — skipping Vue panel."
    warn "Use the standalone HTML panel instead, or see WIRING.md."
fi

# ── Step 5: moonraker.conf reminder ─────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           Almost done!                   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Add this to ${CYAN}moonraker.conf${NC}:"
echo ""
echo "    [esteps_calibrator]"
echo ""
echo -e "  Add this to ${CYAN}printer.cfg${NC}:"
echo ""
echo "    [include esteps_calibrator.cfg]"
echo ""
echo -e "  Then restart Moonraker and Klipper."
echo ""

# ── Step 6: Restart Moonraker ────────────────────────────────
read -p "  Restart Moonraker now? [y/N] " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    sudo systemctl restart moonraker
    ok "Moonraker restarted"
fi

echo ""
ok "Installation complete!"
echo ""
