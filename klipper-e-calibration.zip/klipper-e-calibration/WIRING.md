# Wiring EStepsCalibratorPanel into Mainsail

After running install.sh, patch these 3 existing Mainsail files.
All paths are relative to your Mainsail source root.

---

## 1. Register Vuex store — `src/store/index.ts`

```ts
import { esteps } from './esteps'

// Add inside the modules: {} object:
esteps,
```

---

## 2. Handle websocket notification — `src/store/server/index.ts`

Find where moonraker notifications are dispatched and add:

```ts
case 'esteps_calibrator:state_changed':
    dispatch('esteps/onNotification', payload, { root: true })
    break
```

---

## 3. Add panel to dashboard — `src/views/Dashboard.vue`

```html
<e-steps-calibrator-panel />
```

Add it wherever you want the panel to appear (e.g. next to ExtruderControlPanel).
The panel hides itself automatically when the moonraker component isn't installed.

---

## Rebuild Mainsail

```bash
cd ~/mainsail-src
npm install
npm run build
sudo cp -r dist/* /path/to/mainsail/webroot/
```
