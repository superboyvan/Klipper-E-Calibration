<template>
    <panel
        v-if="showPanel"
        :icon="mdiRulerSquareCompass"
        :title="$t('Panels.EStepsCalibratorPanel.Headline')"
        :collapsible="true"
        card-class="e-steps-calibrator-panel">

        <!-- ── IDLE ─────────────────────────────────────────────────────── -->
        <template v-if="calibrationState === 'idle'">
            <v-card-text>
                <p class="text--secondary mb-4">
                    {{ $t('Panels.EStepsCalibratorPanel.Description') }}
                </p>
                <v-text-field
                    v-model.number="preheatTemp"
                    :label="$t('Panels.EStepsCalibratorPanel.PreheatTemp')"
                    type="number"
                    outlined
                    dense
                    hide-details
                    suffix="°C"
                    :min="150"
                    :max="350"
                    class="mb-4" />
                <v-btn
                    color="primary"
                    block
                    :disabled="printerIsPrinting"
                    @click="startCalibration">
                    <v-icon left>{{ mdiPlay }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Start') }}
                </v-btn>
            </v-card-text>
        </template>

        <!-- ── HEATING ───────────────────────────────────────────────────── -->
        <template v-else-if="calibrationState === 'heating'">
            <v-card-text>
                <v-alert dense outlined type="info" class="mb-4">
                    <strong>{{ $t('Panels.EStepsCalibratorPanel.Alerts.HeatingTitle') }}</strong><br />
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.HeatingDesc', { temp: preheatTemp }) }}
                </v-alert>
                <v-alert dense outlined color="warning" class="mb-4">
                    <v-icon left color="warning">{{ mdiMarker }}</v-icon>
                    <strong>{{ $t('Panels.EStepsCalibratorPanel.Alerts.MarkTitle') }}</strong><br />
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.MarkDesc') }}
                </v-alert>
                <div class="d-flex align-center justify-center my-4">
                    <v-progress-circular indeterminate color="primary" class="mr-3" />
                    <span class="text--secondary">
                        {{ $t('Panels.EStepsCalibratorPanel.WaitingForTemp') }}
                        {{ extruderTemp | round(1) }} / {{ preheatTemp }} °C
                    </span>
                </div>
                <v-btn text block color="error" @click="resetCalibration">
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Cancel') }}
                </v-btn>
            </v-card-text>
        </template>

        <!-- ── READY TO MARK ──────────────────────────────────────────────── -->
        <template v-else-if="calibrationState === 'ready_to_mark'">
            <v-card-text>
                <v-alert dense outlined color="success" class="mb-4">
                    <v-icon left color="success">{{ mdiCheck }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.TempReached', { temp: preheatTemp }) }}
                </v-alert>
                <v-alert dense outlined color="warning" class="mb-4">
                    <v-icon left color="warning">{{ mdiMarker }}</v-icon>
                    <strong>{{ $t('Panels.EStepsCalibratorPanel.Alerts.MarkTitle') }}</strong><br />
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.MarkDesc') }}
                </v-alert>

                <!-- Filament diagram -->
                <div class="e-steps-diagram my-4">
                    <div class="e-steps-diagram__extruder">
                        <v-icon large color="grey darken-1">{{ mdiPrinter3dNozzle }}</v-icon>
                        <span class="caption">{{ $t('Panels.EStepsCalibratorPanel.Diagram.Extruder') }}</span>
                    </div>
                    <div class="e-steps-diagram__filament">
                        <div class="e-steps-diagram__bar" />
                        <div class="e-steps-diagram__mark">
                            <span class="caption error--text font-weight-bold">120mm</span>
                        </div>
                    </div>
                </div>

                <v-btn
                    color="primary"
                    block
                    class="mb-2"
                    @click="markDone">
                    <v-icon left>{{ mdiCheck }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.MarkDone') }}
                </v-btn>
                <v-btn text block color="error" @click="resetCalibration">
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Cancel') }}
                </v-btn>
            </v-card-text>
        </template>

        <!-- ── EXTRUDING ──────────────────────────────────────────────────── -->
        <template v-else-if="calibrationState === 'extruding'">
            <v-card-text class="text-center">
                <v-progress-circular indeterminate color="primary" size="48" class="mb-4" />
                <p class="text--secondary">
                    {{ $t('Panels.EStepsCalibratorPanel.Extruding') }}
                </p>
                <p class="caption text--disabled">
                    {{ $t('Panels.EStepsCalibratorPanel.DontTouch') }}
                </p>
            </v-card-text>
        </template>

        <!-- ── WAITING MEASUREMENT ───────────────────────────────────────── -->
        <template v-else-if="calibrationState === 'waiting_measurement'">
            <v-card-text>
                <v-alert dense outlined color="success" class="mb-4">
                    <v-icon left color="success">{{ mdiCheck }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.ExtrusionDone') }}
                </v-alert>
                <v-alert dense outlined color="info" class="mb-4">
                    {{ $t('Panels.EStepsCalibratorPanel.Alerts.MeasureDesc') }}
                </v-alert>
                <v-text-field
                    v-model.number="remainder"
                    :label="$t('Panels.EStepsCalibratorPanel.RemainderLabel')"
                    type="number"
                    outlined
                    dense
                    hide-details
                    suffix="mm"
                    :min="0"
                    :max="120"
                    step="0.1"
                    class="mb-4" />
                <v-btn
                    color="primary"
                    block
                    class="mb-2"
                    :disabled="remainder === null"
                    @click="calculate">
                    <v-icon left>{{ mdiCalculator }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Calculate') }}
                </v-btn>
                <v-btn text block color="error" @click="resetCalibration">
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Cancel') }}
                </v-btn>
            </v-card-text>
        </template>

        <!-- ── DONE / RESULTS ─────────────────────────────────────────────── -->
        <template v-else-if="calibrationState === 'done'">
            <v-card-text>
                <v-simple-table dense class="mb-4">
                    <tbody>
                        <tr>
                            <td class="text--secondary">{{ $t('Panels.EStepsCalibratorPanel.Results.Commanded') }}</td>
                            <td class="text-right font-weight-bold">100.0 mm</td>
                        </tr>
                        <tr>
                            <td class="text--secondary">{{ $t('Panels.EStepsCalibratorPanel.Results.Actual') }}</td>
                            <td class="text-right font-weight-bold" :class="errorClass">
                                {{ results.actual_extruded | round(2) }} mm
                            </td>
                        </tr>
                        <tr>
                            <td class="text--secondary">{{ $t('Panels.EStepsCalibratorPanel.Results.Error') }}</td>
                            <td class="text-right font-weight-bold" :class="errorClass">
                                {{ results.error_percent > 0 ? '+' : '' }}{{ results.error_percent | round(2) }}%
                            </td>
                        </tr>
                        <tr>
                            <td class="text--secondary">{{ $t('Panels.EStepsCalibratorPanel.Results.OldRotDist') }}</td>
                            <td class="text-right">{{ results.current_rotation_distance | round(6) }}</td>
                        </tr>
                    </tbody>
                </v-simple-table>

                <v-sheet color="primary" rounded class="pa-3 mb-4 text-center">
                    <div class="caption white--text">{{ $t('Panels.EStepsCalibratorPanel.Results.NewRotDist') }}</div>
                    <div class="text-h5 white--text font-weight-bold">
                        {{ results.new_rotation_distance | round(6) }}
                    </div>
                    <div class="caption white--text opacity-60">
                        {{ $t('Panels.EStepsCalibratorPanel.Results.AppliedLive') }}
                    </div>
                </v-sheet>

                <v-btn
                    color="success"
                    block
                    class="mb-2"
                    @click="saveConfig">
                    <v-icon left>{{ mdiContentSave }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.Save') }}
                </v-btn>
                <v-btn text block @click="resetCalibration">
                    <v-icon left>{{ mdiRefresh }}</v-icon>
                    {{ $t('Panels.EStepsCalibratorPanel.Buttons.RunAgain') }}
                </v-btn>
            </v-card-text>
        </template>

        <!-- ── STEP INDICATOR (footer) ────────────────────────────────────── -->
        <template #actions>
            <v-card-actions class="pt-0">
                <v-stepper :value="currentStep" class="elevation-0 pa-0 flex-grow-1" style="background:transparent">
                    <v-stepper-header>
                        <v-stepper-step step="1" :complete="currentStep > 1" />
                        <v-divider />
                        <v-stepper-step step="2" :complete="currentStep > 2" />
                        <v-divider />
                        <v-stepper-step step="3" :complete="currentStep > 3" />
                        <v-divider />
                        <v-stepper-step step="4" :complete="currentStep > 4" />
                        <v-divider />
                        <v-stepper-step step="5" :complete="currentStep === 5" />
                    </v-stepper-header>
                </v-stepper>
            </v-card-actions>
        </template>
    </panel>
</template>

<script lang="ts">
import {
    mdiRulerSquareCompass,
    mdiPlay,
    mdiCheck,
    mdiMarker,
    mdiCalculator,
    mdiContentSave,
    mdiRefresh,
    mdiPrinter3dNozzle,
} from '@mdi/js'
import { Component, Mixins, Watch } from 'vue-property-decorator'
import BaseMixin from '@/components/mixins/base'
import ControlMixin from '@/components/mixins/control'

@Component
export default class EStepsCalibratorPanel extends Mixins(BaseMixin, ControlMixin) {
    // MDI icons
    mdiRulerSquareCompass = mdiRulerSquareCompass
    mdiPlay = mdiPlay
    mdiCheck = mdiCheck
    mdiMarker = mdiMarker
    mdiCalculator = mdiCalculator
    mdiContentSave = mdiContentSave
    mdiRefresh = mdiRefresh
    mdiPrinter3dNozzle = mdiPrinter3dNozzle

    // Local state
    preheatTemp: number = 200
    remainder: number | null = null

    // ── Computed ───────────────────────────────────────────────────────────

    get showPanel(): boolean {
        return this.klipperReadyForGui && this.isEStepsCalibratorAvailable
    }

    get isEStepsCalibratorAvailable(): boolean {
        // True when the moonraker-esteps component is loaded
        return 'esteps_calibrator' in (this.$store.state.server?.components ?? {})
    }

    get calibrationState(): string {
        return this.$store.state.esteps?.state ?? 'idle'
    }

    get results() {
        return this.$store.state.esteps?.results ?? {}
    }

    get extruderTemp(): number {
        return this.$store.state.printer?.extruder?.temperature ?? 0
    }

    get currentStep(): number {
        const map: Record<string, number> = {
            idle: 1,
            heating: 2,
            ready_to_mark: 2,
            extruding: 3,
            waiting_measurement: 4,
            done: 5,
        }
        return map[this.calibrationState] ?? 1
    }

    get errorClass(): string {
        const err = Math.abs(this.results.error_percent ?? 0)
        if (err < 1) return 'success--text'
        if (err < 3) return 'warning--text'
        return 'error--text'
    }

    // ── Watchers ───────────────────────────────────────────────────────────

    @Watch('calibrationState')
    onStateChange(newState: string) {
        // Reset local remainder input when starting fresh
        if (newState === 'idle' || newState === 'heating') {
            this.remainder = null
        }
    }

    // ── Methods ────────────────────────────────────────────────────────────

    async startCalibration() {
        try {
            await this.$axios.post('/server/esteps/start', { temp: this.preheatTemp })
        } catch (e) {
            console.error('[EStepsCalibrator] start failed', e)
        }
    }

    async markDone() {
        try {
            await this.$axios.post('/server/esteps/mark_done')
        } catch (e) {
            console.error('[EStepsCalibrator] mark_done failed', e)
        }
    }

    async calculate() {
        if (this.remainder === null) return
        try {
            await this.$axios.post('/server/esteps/calculate', { remainder: this.remainder })
        } catch (e) {
            console.error('[EStepsCalibrator] calculate failed', e)
        }
    }

    async saveConfig() {
        try {
            await this.$axios.post('/server/esteps/save')
        } catch (e) {
            console.error('[EStepsCalibrator] save failed', e)
        }
    }

    async resetCalibration() {
        try {
            await this.$axios.post('/server/esteps/reset')
        } catch (e) {
            console.error('[EStepsCalibrator] reset failed', e)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    mounted() {
        // Sync initial state from Moonraker on panel load
        this.$store.dispatch('esteps/fetchStatus')
    }
}
</script>

<style scoped>
.e-steps-diagram {
    display: flex;
    align-items: center;
    gap: 12px;
    background: rgba(255, 255, 255, 0.04);
    border-radius: 8px;
    padding: 16px;
}

.e-steps-diagram__extruder {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    flex-shrink: 0;
}

.e-steps-diagram__filament {
    flex: 1;
    position: relative;
    display: flex;
    align-items: center;
}

.e-steps-diagram__bar {
    width: 100%;
    height: 10px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 4px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.e-steps-diagram__mark {
    position: absolute;
    right: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.e-steps-diagram__mark::before {
    content: '';
    display: block;
    width: 2px;
    height: 24px;
    background: var(--v-error-base);
    margin-bottom: 2px;
}
</style>
