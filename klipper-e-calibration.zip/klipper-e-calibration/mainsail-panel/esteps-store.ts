/*
 * E-Steps Calibrator – Vuex store module
 * Mirrors the pattern used by other Mainsail store modules (e.g. server/timelapse)
 */

import { Module } from 'vuex'
import axios from 'axios'

export interface EStepsState {
    state: string
    results: {
        current_rotation_distance: number | null
        new_rotation_distance: number | null
        actual_extruded: number | null
        remainder: number | null
        error_percent: number | null
    }
}

const defaultState = (): EStepsState => ({
    state: 'idle',
    results: {
        current_rotation_distance: null,
        new_rotation_distance: null,
        actual_extruded: null,
        remainder: null,
        error_percent: null,
    },
})

export const esteps: Module<EStepsState, any> = {
    namespaced: true,

    state: defaultState(),

    getters: {
        getState: (state) => state.state,
        getResults: (state) => state.results,
    },

    mutations: {
        setState(state, payload: string) {
            state.state = payload
        },

        setResults(state, payload: Partial<EStepsState['results']>) {
            state.results = { ...state.results, ...payload }
        },

        reset(state) {
            Object.assign(state, defaultState())
        },
    },

    actions: {
        /**
         * Called on app init and panel mount to sync current server state.
         */
        async fetchStatus({ commit }) {
            try {
                const { data } = await axios.get('/server/esteps/status')
                commit('setState', data.result?.state ?? 'idle')
                commit('setResults', data.result?.results ?? {})
            } catch (e) {
                // Component not installed — silently ignore
            }
        },

        /**
         * Called by the Moonraker websocket handler when we receive
         * the "esteps_calibrator:state_changed" notification.
         */
        onNotification({ commit, dispatch }, payload: { state: string }) {
            commit('setState', payload.state)
            // Re-fetch full status so we also get updated results
            dispatch('fetchStatus')
        },
    },
}
