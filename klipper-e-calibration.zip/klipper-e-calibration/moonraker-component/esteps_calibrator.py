# E-Steps / Rotation Distance Calibrator - Moonraker Component
# A guided interactive calibration wizard for Klipper extruder calibration
#
# Copyright (C) 2024
# Based on the moonraker-timelapse component structure by mainsail-crew
#
# This file may be distributed under the terms of the GNU GPLv3 license.

from __future__ import annotations
import logging
import asyncio
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from moonraker.confighelper import ConfigHelper
    from moonraker.websockets import WebRequest

ESTEPS_CALIBRATOR_VERSION = "1.0.0"


class EStepsCalibrator:
    """
    Moonraker component that manages E-Step calibration state and exposes
    REST endpoints consumed by the calibration UI panel.
    """

    def __init__(self, config: ConfigHelper) -> None:
        self.server = config.get_server()
        self.name = config.get_name()

        # Component state
        self.state: str = "idle"          # idle | heating | ready_to_mark | extruding | waiting_measurement | done
        self.preheat_temp: float = config.getfloat("preheat_temp", 200.0)
        self.extrude_speed: float = config.getfloat("extrude_speed", 50.0)
        self.mark_distance: float = config.getfloat("mark_distance", 120.0)
        self.extrude_amount: float = config.getfloat("extrude_amount", 100.0)

        self.current_rotation_distance: Optional[float] = None
        self.new_rotation_distance: Optional[float] = None
        self.actual_extruded: Optional[float] = None
        self.remainder: Optional[float] = None

        # Register REST endpoints
        self.server.register_endpoint(
            "/server/esteps/status", ["GET"],
            self._handle_status
        )
        self.server.register_endpoint(
            "/server/esteps/start", ["POST"],
            self._handle_start
        )
        self.server.register_endpoint(
            "/server/esteps/mark_done", ["POST"],
            self._handle_mark_done
        )
        self.server.register_endpoint(
            "/server/esteps/calculate", ["POST"],
            self._handle_calculate
        )
        self.server.register_endpoint(
            "/server/esteps/save", ["POST"],
            self._handle_save
        )
        self.server.register_endpoint(
            "/server/esteps/reset", ["POST"],
            self._handle_reset
        )

        # Register notification so frontend can subscribe
        self.server.register_notification("esteps_calibrator:state_changed")

        logging.info(f"E-Steps Calibrator v{ESTEPS_CALIBRATOR_VERSION} loaded")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _notify_state_change(self) -> None:
        self.server.send_event(
            "esteps_calibrator:state_changed",
            {"state": self.state}
        )

    async def _run_gcode(self, gcode: str) -> None:
        klippy = self.server.lookup_component("klippy_apis")
        await klippy.run_gcode(gcode)

    async def _query_printer_object(self, obj: str, key: str):
        klippy = self.server.lookup_component("klippy_apis")
        result = await klippy.query_objects({obj: None})
        return result.get(obj, {}).get(key)

    # ------------------------------------------------------------------
    # Endpoint handlers
    # ------------------------------------------------------------------

    async def _handle_status(self, web_request: WebRequest) -> dict:
        return {
            "state": self.state,
            "version": ESTEPS_CALIBRATOR_VERSION,
            "settings": {
                "preheat_temp": self.preheat_temp,
                "extrude_speed": self.extrude_speed,
                "mark_distance": self.mark_distance,
                "extrude_amount": self.extrude_amount,
            },
            "results": {
                "current_rotation_distance": self.current_rotation_distance,
                "new_rotation_distance": self.new_rotation_distance,
                "actual_extruded": self.actual_extruded,
                "remainder": self.remainder,
            }
        }

    async def _handle_start(self, web_request: WebRequest) -> dict:
        """
        Step 1: heat hotend and prepare for marking.
        Accepts optional temp= parameter.
        """
        if self.state not in ("idle", "done"):
            return {"error": f"Cannot start from state '{self.state}'. Reset first."}

        temp = web_request.get_float("temp", self.preheat_temp)
        self.preheat_temp = temp
        self.state = "heating"
        self._notify_state_change()

        # Read current rotation_distance
        try:
            cfg = await self._query_printer_object("configfile", "settings")
            self.current_rotation_distance = float(
                cfg.get("extruder", {}).get("rotation_distance", 0)
            )
        except Exception as e:
            logging.warning(f"Could not read rotation_distance: {e}")
            self.current_rotation_distance = None

        # Heat and wait
        asyncio.ensure_future(self._heat_and_prepare(temp))

        return {
            "state": self.state,
            "message": f"Heating hotend to {temp}°C..."
        }

    async def _heat_and_prepare(self, temp: float) -> None:
        try:
            await self._run_gcode(f"M109 S{temp}")           # heat and wait
            await self._run_gcode("SET_PRESSURE_ADVANCE ADVANCE=0")
            await self._run_gcode("M83")                      # relative extrusion
            self.state = "ready_to_mark"
            self._notify_state_change()
            logging.info("E-Steps: Hotend ready, waiting for user to mark filament")
        except Exception as e:
            logging.error(f"E-Steps heating error: {e}")
            self.state = "idle"
            self._notify_state_change()

    async def _handle_mark_done(self, web_request: WebRequest) -> dict:
        """Step 2: user has marked the filament, now extrude."""
        if self.state != "ready_to_mark":
            return {"error": f"Not in 'ready_to_mark' state (current: {self.state})"}

        self.state = "extruding"
        self._notify_state_change()
        asyncio.ensure_future(self._do_extrude())
        return {"state": self.state, "message": f"Extruding {self.extrude_amount}mm..."}

    async def _do_extrude(self) -> None:
        try:
            speed_mm_per_min = self.extrude_speed * 60
            await self._run_gcode(f"G1 E{self.extrude_amount} F{speed_mm_per_min}")
            await self._run_gcode("M400")  # wait for move
            self.state = "waiting_measurement"
            self._notify_state_change()
            logging.info("E-Steps: Extrusion complete, waiting for measurement")
        except Exception as e:
            logging.error(f"E-Steps extrude error: {e}")
            self.state = "idle"
            self._notify_state_change()

    async def _handle_calculate(self, web_request: WebRequest) -> dict:
        """Step 3: receive user's measurement and calculate new rotation_distance."""
        if self.state != "waiting_measurement":
            return {"error": f"Not in 'waiting_measurement' state (current: {self.state})"}

        remainder = web_request.get_float("remainder")
        if remainder < 0 or remainder > self.mark_distance:
            return {"error": f"Remainder must be between 0 and {self.mark_distance}mm"}

        self.remainder = remainder
        # actual extruded = mark_distance - remainder
        self.actual_extruded = self.mark_distance - remainder

        if self.current_rotation_distance and self.current_rotation_distance > 0:
            self.new_rotation_distance = self.current_rotation_distance * (
                self.actual_extruded / self.extrude_amount
            )
        else:
            self.new_rotation_distance = None

        error_pct = ((self.actual_extruded - self.extrude_amount) / self.extrude_amount) * 100

        # Apply the new value live via gcode
        if self.new_rotation_distance:
            try:
                await self._run_gcode(
                    f"SET_EXTRUDER_ROTATION_DISTANCE EXTRUDER=extruder "
                    f"DISTANCE={self.new_rotation_distance:.6f}"
                )
            except Exception as e:
                logging.warning(f"Could not apply new rotation_distance: {e}")

        self.state = "done"
        self._notify_state_change()

        return {
            "state": self.state,
            "remainder": self.remainder,
            "actual_extruded": self.actual_extruded,
            "commanded": self.extrude_amount,
            "error_percent": round(error_pct, 2),
            "current_rotation_distance": self.current_rotation_distance,
            "new_rotation_distance": self.new_rotation_distance,
        }

    async def _handle_save(self, web_request: WebRequest) -> dict:
        """Save the new rotation_distance permanently via SAVE_CONFIG."""
        if self.state != "done" or not self.new_rotation_distance:
            return {"error": "No calibration result to save. Run calibration first."}

        try:
            await self._run_gcode("SAVE_CONFIG")
            return {"success": True, "message": "Saved! Klipper will restart."}
        except Exception as e:
            return {"error": str(e)}

    async def _handle_reset(self, web_request: WebRequest) -> dict:
        """Reset state machine back to idle."""
        self.state = "idle"
        self.remainder = None
        self.actual_extruded = None
        self.new_rotation_distance = None
        self._notify_state_change()
        return {"state": self.state}


def load_component(config: ConfigHelper) -> EStepsCalibrator:
    return EStepsCalibrator(config)
